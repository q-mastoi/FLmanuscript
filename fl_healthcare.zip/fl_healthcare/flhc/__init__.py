"""FL-Healthcare: federated learning framework for the IJCIS manuscript use case."""
__version__ = "1.0.0"
