"""Client partitioning: IID or label-skewed non-IID via Dirichlet(alpha) (Section 5.3)."""
import numpy as np


def partition_indices(strat_labels, n_clients, scheme="dirichlet", alpha=0.5, seed=0,
                      min_size=20, max_tries=1000):
    """
    Split positions 0..len(strat_labels)-1 across clients.

    iid       : uniform random split into equal-sized shards.
    dirichlet : for each class c, client proportions p ~ Dir(alpha * 1_K) and the
                samples of c are divided accordingly (Hsu et al., 2019). Draws are
                repeated until every client holds at least `min_size` samples.
    """
    rng = np.random.default_rng(seed)
    labels = np.asarray(strat_labels)
    n = len(labels)
    if scheme == "iid":
        return [np.sort(p) for p in np.array_split(rng.permutation(n), n_clients)]
    if scheme != "dirichlet":
        raise ValueError(scheme)
    for _ in range(max_tries):
        parts = [[] for _ in range(n_clients)]
        for c in np.unique(labels):
            ids = rng.permutation(np.where(labels == c)[0])
            props = rng.dirichlet(alpha * np.ones(n_clients))
            cuts = (np.cumsum(props) * len(ids)).astype(int)[:-1]
            for k, chunk in enumerate(np.split(ids, cuts)):
                parts[k].extend(chunk.tolist())
        if min(len(p) for p in parts) >= min_size:
            return [np.sort(np.array(p)) for p in parts]
    raise RuntimeError("Could not satisfy min_size; lower --min-client-size or raise alpha.")


def split_local(indices, val_frac, seed):
    """Hold out part of each client's data for client-level evaluation (Figure 9)."""
    rng = np.random.default_rng(seed)
    p = rng.permutation(indices)
    k = max(1, int(round(val_frac * len(p))))
    return np.sort(p[k:]), np.sort(p[:k])
