"""Model architectures (Section 5.4): three-layer MLP for signal/tabular data, ResNet-18 for images."""
import warnings

import torch
import torch.nn as nn


class MLP(nn.Module):
    """Three fully connected layers, ReLU activations, dropout p = 0.3."""

    def __init__(self, in_dim, hidden=(256, 128), n_out=2, dropout=0.3):
        super().__init__()
        layers, d = [], in_dim
        for h in hidden:
            layers += [nn.Linear(d, h), nn.ReLU(), nn.Dropout(dropout)]
            d = h
        layers.append(nn.Linear(d, n_out))
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


def resnet18(pretrained=True, weights_path=None, n_out=2):
    """ResNet-18 with a 2-class head. Returns (model, weights_source)."""
    from torchvision.models import resnet18 as tv_resnet18
    model, source = tv_resnet18(weights=None), "random"
    if weights_path:
        state = torch.load(weights_path, map_location="cpu")
        model.load_state_dict(state, strict=False)
        source = f"file:{weights_path}"
    elif pretrained:
        try:
            from torchvision.models import ResNet18_Weights
            model = tv_resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)
            source = "imagenet"
        except Exception as e:  # offline machine
            warnings.warn(f"ImageNet weights unavailable ({e}); using random initialisation. "
                          "Pass --weights PATH to a local resnet18 checkpoint.")
    model.fc = nn.Linear(model.fc.in_features, n_out)
    return model, source


def make_model(task, args, pretrained=False):
    """Build the model for a task. DP runs replace BatchNorm with GroupNorm (Opacus requirement)."""
    if task.kind == "tabular":
        model, source = MLP(task.input_dim, tuple(args.hidden), dropout=args.dropout), "random"
    else:
        model, source = resnet18(pretrained=pretrained, weights_path=args.weights)
    _remove_inplace_ops(model)             # Opacus per-sample gradients need out-of-place ops
    if args.dp:
        from opacus.validators import ModuleValidator
        model = ModuleValidator.fix(model)
        errors = ModuleValidator.validate(model, strict=False)
        if errors:
            raise RuntimeError(f"Model not compatible with Opacus: {errors}")
    return model, source


try:
    from torchvision.models.resnet import BasicBlock as _TVBasicBlock

    class OutOfPlaceBasicBlock(_TVBasicBlock):
        """torchvision BasicBlock with `out = out + identity` instead of `out += identity`."""

        def forward(self, x):
            identity = x
            out = self.relu(self.bn1(self.conv1(x)))
            out = self.bn2(self.conv2(out))
            if self.downsample is not None:
                identity = self.downsample(x)
            return self.relu(out + identity)
except ImportError:  # torchvision only needed for image tasks
    _TVBasicBlock = None


def _remove_inplace_ops(model):
    for m in model.modules():
        if isinstance(m, nn.ReLU):
            m.inplace = False
        if _TVBasicBlock is not None and type(m) is _TVBasicBlock:
            m.__class__ = OutOfPlaceBasicBlock


def get_weights(model):
    return [v.detach().cpu().numpy().copy() for v in model.state_dict().values()]


def set_weights(model, weights):
    keys = list(model.state_dict().keys())
    model.load_state_dict({k: torch.as_tensor(w) for k, w in zip(keys, weights)}, strict=True)


def payload_bytes(weights, fp16=False):
    """Bytes needed to send one copy of the model (floats at 2 bytes if FP16)."""
    total = 0
    for w in weights:
        if w.dtype.kind == "f":
            total += w.size * (2 if fp16 else w.itemsize)
        else:
            total += w.nbytes
    return int(total)


def fp16_roundtrip(weights):
    """Simulate FP16 transmission: cast floats to float16 and back (lossy)."""
    return [w.astype("float16").astype(w.dtype) if w.dtype.kind == "f" else w for w in weights]
